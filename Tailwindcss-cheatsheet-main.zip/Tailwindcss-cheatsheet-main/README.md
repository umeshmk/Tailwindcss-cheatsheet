# Tailwindcss-cheatsheet (v-2.0)

### A very elegant and helpful Tailwindcss cheatsheet.

- [Tailwindcss-cheatsheet-2.0](https://umeshmk.github.io/Tailwindcss-cheatsheet/)
- [Tailwindcss-cheatsheet-1.0](https://umeshmk.github.io/Tailwindcss-cheatsheet/v1)

---

![](https://i.imgur.com/rrC2G38.png)
